---
seo_title: "<50-60 chars, topic first>"
meta_description: "<~150 chars, earns the click>"
url: /blog/<slug>/
h1: "<reader-facing promise>"
primary_keyword: ""
secondary_keywords: []
intent: informational
audience: ""
author: "<real author>"
date_published: YYYY-MM-DD
date_modified: YYYY-MM-DD
---

# <H1>

<Intro: 2-4 sentences. Direct answer or the core claim. Who this is for and what they will be able to do.>

## <H2: first question the reader has>

<Answer first. Then explanation, example, source.>

## <H2: next question>

### <H3: sub-point>

## <H2: worked example / data / comparison table>

| Criteria | Option A | Option B |
|---|---|---|

## <H2: what to do next>

<Practical steps. Link to the relevant commercial page with a descriptive anchor.>

<CTA block: primary CTA matched to stage; secondary lower-commitment CTA.>

---
**Sources**
1. <Publisher>, "<Title>", <date>. <URL>

**Internal links used**: <anchor -> URL>

**Images**: <file-name.webp> | alt: "<description>" | placement

**Schema**: Article + BreadcrumbList (JSON-LD attached separately)

**Fact-check**: <claim | source | status>
