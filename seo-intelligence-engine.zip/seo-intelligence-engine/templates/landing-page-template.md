# Landing Page Copy Deck: <page name>

**URL**: /path/  |  **Primary keyword**: ...  |  **Audience**: ...  |  **Primary CTA**: ...

**SEO title (n chars)**: ...
**Meta description (n chars)**: ...

---

## 1. Hero
- H1:
- Subhead (1-2 sentences: who it is for + outcome):
- Primary CTA button:
- Secondary CTA:
- Proof line (real logo strip / metric with source / [CONFIRM]):

## 2. Problem (H2)
<The cost of the status quo in the buyer's words.>

## 3. Outcome (H2)
<What changes for the buyer. Measurable only if substantiated.>

## 4. How it works (H2)
1. Step:
2. Step:
3. Step:

## 5. Capabilities tied to jobs (H2)
| Job the buyer needs done | Capability | Evidence |
|---|---|---|

## 6. Proof (H2)
<Approved case study summary, quote with name/title, or [CONFIRM]>

## 7. Integrations / specs (H2)

## 8. Objections (H2: questions buyers ask)
- Q: / A:

## 9. Final CTA (H2)

---
**Internal links in**: <cluster pages that should link here with anchors>
**Internal links out**: <anchor -> URL>
**Schema**: <types> (JSON-LD attached)
**Tracking**: <events: cta_click, form_start, form_submit>
**Dev notes**: <canonical, hero image size/preload, CWV>
**Open confirmations**: <list of [CONFIRM] items>
