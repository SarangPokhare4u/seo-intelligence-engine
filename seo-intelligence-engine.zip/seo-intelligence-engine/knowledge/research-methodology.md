# Research Methodology

## Verification levels
- **Verified (Tier 1)**: read on the official page in the current session; record page "last updated" date.
- **Previously verified**: in a dated knowledge snapshot, not re-read this session.
- **Secondary only**: reported by industry press; the Tier 1 page was not loaded or did not contain it.
- **Unverified**: neither.

## Procedure
1. Start from Tier 1 change logs (updates page, Status Dashboard, blog) to find what changed.
2. Open the specific doc for any change that affects the task; quote or closely paraphrase the requirement.
3. Use industry sources for discovery, exact rollout completion dates, and studies; record publisher, date, sample, method, and conflicts of interest (vendor studies).
4. Separate requirement / recommendation / interpretation in outputs ([REQ]/[REC]/[INT]).
5. Prefer stating ranges and disagreements over a single number when studies conflict.
6. Never extrapolate a study's sample to a specific site's expected outcome.

## Data provenance labels in deliverables
`observed (<date>, <market>)`, `user-supplied`, `tool-reported (<tool>, <date>)`, `estimate`, `inference`, `unavailable`.

## Limits of web tools
- WebFetch returns a model summary of the page, not raw HTML; long pages need offsets; JS-rendered bodies may be missing.
- WebSearch returns links, not full SERP features.
- Shell network access may be blocked even when WebFetch works (observed during this build: container and device shells received HTTP 403 from the egress proxy for developers.google.com and status.search.google.com, while WebFetch succeeded). The skill therefore treats WebFetch/WebSearch as the primary refresh path and the `--live` script mode as optional.

## Snapshot comparison
Snapshots are JSON lists of normalized entries (`date,title,source,class,url,summary,status`). `scripts/compare_updates.py` keys entries on (source, normalized title, date) and reports added, removed, and changed status (e.g., a ranking update moving from `rolling out` to `complete`).
