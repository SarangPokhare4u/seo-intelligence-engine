# Content Brief: <working title>

| Field | Value |
|---|---|
| Date | YYYY-MM-DD |
| Owner / writer | |
| Target URL | /path/ (existing or NEW) |
| Content type | blog / pillar / cluster / landing / comparison / ... |
| Primary keyword | (source, date) |
| Secondary keywords | |
| Questions to answer | (PAA, sales, support) |
| Search intent | informational / commercial / transactional / navigational |
| Buyer stage | TOFU / MOFU / BOFU |
| Audience | role, seniority, knowledge level |
| Business goal | |
| Conversion action | CTA + destination |
| Market / language | |

## SERP summary (observed YYYY-MM-DD, <market>)
- Dominant page type and format:
- What top results cover well:
- Gaps:
- Features observed (only if seen):

## Original angle
What this page offers that others do not (data, experience, framework, example):

## Outline
- H1:
- H2:
  - H3:

## Must-include facts (with sources)
| Claim | Source URL | Date | Status |
|---|---|---|---|

## Internal links
| Anchor | Target URL | Placement |
|---|---|---|

## Voice and constraints
Brand rules, banned words, legal notes:

## Success metrics
Visibility / acquisition / conversion targets (as scenarios, not promises):
