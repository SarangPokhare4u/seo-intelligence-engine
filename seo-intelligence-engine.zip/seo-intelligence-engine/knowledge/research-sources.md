# Research Sources (build-time research, 2026-10-17)

Sources opened while building this skill, with what each contributed. Secondary findings are correlation or survey data unless stated.

## Google (Tier 1)
- Documentation updates log: https://developers.google.com/search/updates (entries 2025-01 to 2026-10-16)
- Search Status Dashboard summary: https://status.search.google.com/summary (ranking incidents Dec 2025 to Oct 2026)
- Status incidents JSON: https://status.search.google.com/incidents.json (structure: array of incidents with id, begin, end, external_desc, service_name, most_recent_update, uri)
- Search Central Blog: https://developers.google.com/search/blog (posts 2025-01 to 2026-10)
- AI optimization guide (updated 2026-07-10): https://developers.google.com/search/docs/fundamentals/ai-optimization-guide
- AI features and your website (updated 2025-12-10): https://developers.google.com/search/docs/appearance/ai-features
- Using generative AI content (updated 2026-10-01): https://developers.google.com/search/docs/fundamentals/using-gen-ai-content
- Spam policies (updated 2026-08-28): https://developers.google.com/search/docs/essentials/spam-policies
- Structured data search gallery (updated 2026-10-16): https://developers.google.com/search/docs/appearance/structured-data/search-gallery
- Google blog, Liz Reid on AI search clicks (2025-08-06): https://blog.google/products/search/ai-search-driving-more-queries-higher-quality-clicks/

## Anthropic (skill architecture)
- Agent Skills overview: https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview
- Skill authoring best practices: https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices

## Bing / Microsoft
- AI Performance in Bing Webmaster Tools (2026-02-10): https://blogs.bing.com/webmaster/February-2026/Introducing-AI-Performance-in-Bing-Webmaster-Tools-Public-Preview
- Bing Webmaster Guidelines (GEO section, Feb 2026): https://www.bing.com/webmasters/help/webmaster-guidelines-30fba23a
- Microsoft Advertising, optimizing for AI answers (2025-10-08): https://about.ads.microsoft.com/en/blog/post/october-2025/optimizing-your-content-for-inclusion-in-ai-search-answers

## Studies and industry (Tier 3-5)
- Ahrefs, AI Overviews reduce clicks update (2026-02-04): https://ahrefs.com/blog/ai-overviews-reduce-clicks-update/ (300K keywords, desktop GSC CTR, forecast-based)
- Ahrefs, AIO citations from top 10 (2026-03-02): https://ahrefs.com/blog/ai-overview-citations-top-10/ (37.9%, down from ~76% in July 2025; method changed)
- Ahrefs, brand mentions vs AIO visibility (2025-05-26): https://ahrefs.com/blog/ai-overview-brand-correlation/ (Spearman 0.664 branded mentions; correlation)
- Pew Research (2025-07-22): https://www.pewresearch.org/short-reads/2025/07/22/google-users-are-less-likely-to-click-on-links-when-an-ai-summary-appears/
- Seer Interactive (2025-11-04): https://www.seerinteractive.com/insights/aio-impact-on-google-ctr-september-2025-update
- Semrush AI Overviews study (2025-12-15): https://www.semrush.com/blog/semrush-ai-overviews-study/
- BuzzStream State of Digital PR 2026 (2026-02-09): https://buzzstream.com/blog/state-of-digital-pr/
- Keyword Insights clustering docs: https://docs.keywordinsights.ai/learning-center/the-features/keyword-clustering/
- Ahrefs keyword clustering (modified 2026-08-12): https://ahrefs.com/blog/keyword-clustering
- SearchPilot title tag tests (2025-09-01): https://www.searchpilot.com/resources/case-studies/expanding-your-title-tag-testing-strategy
- SearchPilot removing FAQ schema (2024-11-20): https://www.searchpilot.com/resources/case-studies/removing-valid-faq-schema
- SearchPilot internal linking (2024-05-30): https://searchpilot.com/resources/case-studies/impact-of-internal-linking-seo
- SEJ on Mueller and llms.txt (2025-04-17): https://www.searchenginejournal.com/google-llms-txt-comparable-keywords-meta-tag/544804/
- SEJ on Ahrefs llms.txt request data (2026-06-16): https://searchenginejournal.com/97-of-llms-txt-files-got-no-requests-ahrefs-data-shows/579478
- SEO Kreativ on Googlebot 2 MB limit timeline: https://www.seo-kreativ.de/en/blog/googlebot-2mb-crawl-limit-changes/
- PPC Land on third-party tools guidance (June 2026): https://ppc.land/googles-seo-hiring-guide-now-flags-third-party-tool-risks-and-ai-advice/
- Screaming Frog release history: https://www.screamingfrog.co.uk/seo-spider/release-history/ (v24.0, 2026-05-19: MCP server, crawl comparison)
- Detailed / Ahrefs acquisition (2025-09): https://detailed.com/detailed-ahrefs/
- Search Engine Roundtable update completion posts: https://www.seroundtable.com/ (see latest-verified-updates.md)

## Known unverified items (do not state as fact)
- BrightEdge claim that most AIO citations come from beyond the top 100 (secondary only).
- Body text of the June 2026 Generative AI performance reports blog post (title confirmed; details via PPC Land only).
- Bing AI Performance additions reported June 2026 (third-party only).
