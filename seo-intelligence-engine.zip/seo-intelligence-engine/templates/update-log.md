# SEO Update Log Entry Template

Copy one block per verified change into knowledge/latest-verified-updates.md (newest first).

```
### YYYY-MM-DD | <exact title from source>
- Class: algorithm update | documentation change | policy change | feature launch | feature deprecation | reporting change | incident
- Source: <URL>
- What changed: <one sentence, source wording where possible>
- Effective / rollout: <start> to <end> | status: announced / rolling out / complete / deprecated
- Affected sites: <all / e-commerce / publishers / local / JS sites / ...>
- Impact area: technical | on-page | off-page | content | measurement | AI search
- Action: required | recommended | monitor | none - <what to do>
- Verification: verified on Tier 1 (YYYY-MM-DD) | secondary only | unverified
```

JSON form for scripts/fetch_updates.py --input:

```json
[{"date":"2026-05-08","title":"Deprecating the FAQ rich result feature","source":"docs_updates","class":"feature deprecation","url":"https://developers.google.com/search/updates","summary":"FAQ rich results no longer shown","status":"complete"}]
```
