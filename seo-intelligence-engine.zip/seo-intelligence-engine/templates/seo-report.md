# SEO Report: <site> | <period> (<weekly / monthly / quarterly>)

**Prepared**: YYYY-MM-DD  |  **Data sources**: GSC (<dates>), GA4 (<dates>), CRM (<dates>)  |  **Comparison**: <previous period / YoY>

## Summary
- 3-5 bullets: what changed, why, what we do next.

## Search environment (Phase 2 brief)
- Relevant Google updates/incidents in period with dates and sources.

## Visibility
| Metric | This period | Previous | Change | Note |
|---|---|---|---|---|
| Non-branded impressions | | | | |
| Avg position (priority clusters) | | | | segment-level only |
| AI citations (Bing AI Performance) | | | | if available |

## Acquisition
| Metric | This period | Previous | Change |
|---|---|---|---|
| GSC clicks (non-branded) | | | |
| GA4 organic sessions | | | |
| AI referral sessions | | | |

## Conversion
| Metric | This period | Previous | Change |
|---|---|---|---|
| Organic key events (demo, contact) | | | |
| Organic conversion rate | | | |
| Organic-sourced SQLs / pipeline | | | |

## Pages and clusters
| Cluster / page | Clicks | Change | Conversions | Action |
|---|---|---|---|---|

## Technical health
Indexing changes, crawl anomalies, CWV status by template.

## Work completed / next period plan (P0-P3)

## Caveats
GSC clicks != GA4 sessions; anonymized queries; attribution model used.
