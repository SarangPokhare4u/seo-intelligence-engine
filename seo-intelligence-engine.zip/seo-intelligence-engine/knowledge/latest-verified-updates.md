# Latest Verified Updates (knowledge snapshot)

**Snapshot date**: 2026-10-17. **Status**: verified on Tier 1 pages on that date unless noted. Treat as `previously verified (2026-10-17)` in later runs; re-check live before relying on anything time-sensitive. Machine-readable copy: `knowledge/snapshots/2026-10-17.json`.

## Contents
- A. Confirmed ranking updates and incidents (Status Dashboard)
- B. Documentation, policy, feature, and reporting changes (last 12 months)
- C. Implications already applied in this skill

## A. Confirmed ranking updates and incidents

Dates from https://status.search.google.com/summary (US/Pacific; end dates derived from listed durations) and cross-checked with Search Engine Roundtable.

| Update | Start | Complete | Class |
|---|---|---|---|
| March 2025 core update | 2025-03-13 | 2025-03-27 | algorithm update (secondary source: SER) |
| June 2025 core update | 2025-06-30 | 2025-07-17 | algorithm update (secondary: SER/SEL) |
| August 2025 spam update | 2025-08-26 | 2025-09-22 | algorithm update (secondary: SEL) |
| December 2025 core update | 2025-12-11 | 2025-12-29 | algorithm update |
| February 2026 Discover core update | 2026-02-05 | 2026-02-26/27 | algorithm update (Discover only) |
| Serving issue (15 min) | 2026-02-24 | 2026-02-24 | incident |
| March 2026 spam update | 2026-03-24 | 2026-03-25 | algorithm update |
| March 2026 core update | 2026-03-27 | 2026-04-08 | algorithm update |
| May 2026 core update | 2026-05-21 | 2026-06-02 | algorithm update |
| June 2026 spam update | 2026-06-24 | 2026-06-26 | algorithm update |
| August 2026 spam update | 2026-08-18 | 2026-08-20/21 | algorithm update |
| September 2026 spam update | 2026-09-24 | 2026-10-08 | algorithm update |

No ranking incidents open on 2026-10-16.

## B. Documentation, policy, feature, and reporting changes

Source unless noted: https://developers.google.com/search/updates and https://developers.google.com/search/blog

| Date | Title | Class |
|---|---|---|
| 2026-10-16 | Updating the Indexing API quota page | documentation change |
| 2026-10-08 | Added documentation on the UGC Fresh Data Program | feature launch |
| 2026-10 | Blog: new learning paths (YouTube playlists) | documentation change |
| 2026-10-01 | Updated guidance on using generative AI content (aligned with Search Quality Rater Guidelines 4.6.5/4.6.6) | policy change |
| 2026-09-24 | `creator` property added to VideoObject; `interactionStatistic` clarified | feature launch |
| 2026-09-18 | Local business query support in aggregator and supplier units | feature launch |
| 2026-09-16 | Search profile badge for websites | feature launch |
| 2026-09 | Blog: web multimodal Search performance reporting in Search Console | reporting change |
| 2026-09-08 | Regional differences in Search experience documented | documentation change |
| 2026-08-31 | European Search Dataset Licensing Program page updated | documentation change |
| 2026-08-28 | Site reputation policy updated (EEA enforcement approach) | policy change |
| 2026-08-28 | Favicon supported formats listed | documentation change |
| 2026-08-20 | Custom button for preferred sources | feature launch |
| 2026-07-29 | Guide: social and video platform content in Search Console | reporting change |
| 2026-07-24 | Review snippet guideline: fake and undisclosed incentivized reviews | policy change |
| 2026-07-14 | Package tracking early adopters closed | documentation change |
| 2026-07-10 | Canonicalization troubleshooting: re-evaluation timing | documentation change |
| 2026-07-10 | AI optimization guide last updated | documentation change |
| 2026-07-07 | Product `category`; sale price effective dates | feature launch |
| 2026-07-01 | AMP docs cleanup (viewer, cache, signed exchanges removed) | documentation change |
| 2026-06-17 | Site move: domain variants in Change of Address | documentation change |
| 2026-06-15 | llms.txt: Search does not use these files for ranking | documentation change |
| 2026-06-15 | FAQ rich result documentation removed | feature deprecation |
| 2026-06 | Search Generative AI performance reports in Search Console (rolling out) | reporting change |
| 2026-06-05 | Guidance on third-party SEO tools, services, and advice | documentation change |
| 2026-05-27 | Preferred sources in AI Mode and AI Overviews | feature launch |
| 2026-05-20 | `hasAdultConsideration` for product types | feature launch |
| 2026-05-15 | New guide: optimizing for generative AI features | documentation change |
| 2026-05-15 | Spam policies apply to generative AI responses | policy change |
| 2026-05-08 | FAQ rich result deprecated (stopped showing 2026-05-07 per SEJ) | feature deprecation |
| 2026-04-30 | Preferred sources in all languages | feature launch |
| 2026-04-23 / 04-14 | Spam reports may be used for manual actions | policy change |
| 2026-04-20 | "Read more" deep links section | documentation change |
| 2026-04-13 | New spam policy: back button hijacking | policy change |
| 2026-03-24 | Discussion Forum / QAPage new properties; robots meta outside head | documentation change |
| 2026-03 | Crawler IP range files moved; "Inside Googlebot" post | documentation change |
| 2026-03-04 | Outdated JS accessibility section removed | documentation change |
| 2026-03-02 | Preferred image best practices | documentation change |
| 2026-02-05 | Get on Discover page updated (Discover core update) | documentation change |
| 2026-02-03 | Googlebot file size limits clarified (2 MB text, 64 MB PDF for Search) | documentation change |
| 2026-01-30 | Preferred sources documentation | feature launch |
| 2026-01-06 | Practice problem structured data removed | feature deprecation |
| 2025-12-18 | JS execution on non-200 status codes; crawling docs migration | documentation change |
| 2025-12-17 | Canonicalization best practices for JavaScript | documentation change |
| 2025-12-15 | noindex and JavaScript | documentation change |
| 2025-12-09 | Smaller core updates section | documentation change |
| 2025-12 | Search Console weekly/monthly views, social channels, AI-powered configuration | reporting change |
| 2025-11-20 | Crawling docs moved to crawling infrastructure site; Branded queries filter | documentation change / reporting change |
| 2025-11-19 | Discover Follow feature docs removed | feature deprecation |
| 2025-11-12 | Review nesting clarification; Google-Pinpoint fetcher; merchant shipping policies | documentation change |
| 2025-11 | Search Console custom annotations | reporting change |
| 2025-10 | Query groups in Search Console Insights | reporting change |

Older notable (pre-window): 2025-06-12 retirement of several structured data features (Book actions, Course info, Claim review, Estimated salary, Learning video, Special announcement, Vehicle listing); 2025-06-16 AI Mode counted in Search Console totals; 2025-05-21 AI features documentation added.

## C. Implications already applied in this skill

- FAQ rich results removed from all recommendations (structured-data.md, content-writing.md).
- AI search guidance follows the 2026-05-15 guide: no llms.txt/special schema/chunking claims for Google.
- Spam policy checklist includes back button hijacking and generative AI manipulation.
- Technical checks use the 2 MB Search fetch limit, non-200 rendering note, JS noindex/canonical guidance.
- Content QA reflects the 2026-10-01 generative AI content update (review metadata, alt text, structured data produced with AI).
- Review snippet checks include the 2026-07-24 incentivized review guideline.
- Measurement includes Generative AI performance reports and branded filter where available.
- Third-party metrics labeled as estimates per 2026-06-05 guidance.
